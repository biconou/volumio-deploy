#!/bin/bash
echo "SoundCloud plugin installed"
