#!/bin/bash
echo "SoundCloud plugin uninstalled"
